#include <stdio.h>
#include <stdlib.h>

void foo(char * s, int pos) {
	for (int i = pos; s[i] != '\0'; i++) {
		if (s[i] == '1') {
			s[i] = '0';
			continue;
		}
		if (s[i] == '0') {s[i] = '1';}
	}
}

int main(int argc, char **argv, char **env)
{
	char * s = NULL;
	scanf("%ms", &s);  // казатель на указатель, т.е. аргумент типа char **
	// неявный вызов malloc
	// s указыват на ту область памяти, которая выделена malloc


	int pos;
	scanf("%d", &pos);

	foo(s, pos);

	printf("%s\n", s);
	free(s);

	return 0;
}